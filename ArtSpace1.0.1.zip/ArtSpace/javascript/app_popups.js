import { POPUP_WINDOW } from "./app_formatting.js"

// POPUP window

POPUP_WINDOW('rater-info-icon',
    'Рейтер',
    `Особая система для оценивания дизайнов. 
    Вы можете поставить оценку выбранной работе от 15 до 100 баллов.
    Балл расчитывается по специальной формуле, которая в свою очередь состоит из нескольких критериев.`,
    { right: '0', top: '35px' },
    { width: '230px' })

POPUP_WINDOW('reviewer-info-icon',
    'Рецензер',
    `Помимо обычной оценки, вы можете написать свою рецензию (ваше впечатление от данной работы),
    и объективно оценить все положительные и негативные моменты. Перед написанием, ознакомьтесь с 
    правилами написания рецензий.`,
    { right: '0', top: '35px' },
    { width: '230px' })

POPUP_WINDOW(
    'watch-info-aspect-ratio',
    '',
    `Соотношение сторон`,
    { left: '-250px', top: '0' },
    { width: 'max-content' })

POPUP_WINDOW(
    'watch-info-size',
    '',
    `Размер изображения`,
    { left: '-250px', top: '0' },
    { width: 'max-content' })

POPUP_WINDOW(
    'watch-info-main-colors',
    '',
    `Основные цвета`,
    { left: '-250px', top: '0' },
    { width: 'max-content' })

POPUP_WINDOW(
    'watch-info-file-type',
    '',
    `Тип изображения`,
    { left: '-250px', top: '0' },
    { width: 'max-content' })

POPUP_WINDOW(
    'watch-info-image-weight',
    '',
    `Размер файла`,
    { left: '-250px', top: '0' },
    { width: 'max-content' })

POPUP_WINDOW(
    '.rate-T',
    '',
    `Техника исполнения`,
    { bottom: '35px' },
    { width: 'max-content' })

POPUP_WINDOW(
    '.rate-V',
    '',
    `Визуальная целостность`,
    { bottom: '35px' },
    { width: 'max-content' })

POPUP_WINDOW(
    '.rate-D',
    '',
    `Сложность стиля`,
    { bottom: '35px' },
    { width: 'max-content' })

POPUP_WINDOW(
    '.rate-C',
    '',
    `Концепция`,
    { bottom: '35px' },
    { width: 'max-content' })

POPUP_WINDOW(
    '.rate-OC',
    '',
    `Оригинальность
`,
    { bottom: '35px' },
    { width: 'max-content' })

POPUP_WINDOW(
    '.rate-TI',
    '',
    `Общее впечатление`,
    { bottom: '35px' },
    { width: 'max-content' })