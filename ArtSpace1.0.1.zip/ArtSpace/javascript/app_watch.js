import { GET_DATA, VIEWS_FORMAT, TIME_FORMAT } from "./app_formatting.js"
import { Design, Rate } from "./classes.js"

const design_id = GET_DATA('id')

function getInfoDesign(design_src) {
    const cover = new Image()
    cover.src = design_src

    const info_aspect_ratio = document.getElementById('watch-design-info-ar')
    const info_size = document.getElementById('watch-design-info-sz')
    const info_file_type = document.getElementById('watch-design-info-ft')
    const info_weight = document.getElementById('watch-design-info-wg')
    const info_main_colors = document.getElementById('watch-design-info-mc')

    if (cover) {
        const width = Number(cover.width)
        const height = Number(cover.height)

        function gcd(a, b) {
            return b === 0 ? a : gcd(b, a % b)
        }

        function type(file_name) {
            const file = String(file_name)
            let type = ''
            let check = true

            if (file.includes('.png')) {
                type = 'png'
            }

            if (file.includes('.jpg')) {
                type = 'jpg'
            }

            if (file.includes('.webp')) {
                type = 'webp'
            }

            return type
        }

        function weight(image) {
            fetch(image.src)
                .then(response => {
                    const sizeInBytes = response.headers.get('content-length')
                    if (sizeInBytes) {
                        const sizeInKB = sizeInBytes / 1024;
                        const sizeInMB = sizeInKB / 1024;

                        if (sizeInMB >= 1) {
                            info_weight.textContent = sizeInMB.toFixed(2) + 'MB'
                        } else {
                            info_weight.textContent = sizeInKB.toFixed(2) + 'KB'
                        }
                    } else {
                        info_weight.textContent = 'x'
                    }
                })
                .catch(() => {
                    info_weight.textContent = 'x'
                })
        }

        function colors(image) {
            let colors = []
            image.crossOrigin = "Anonymous"
            image.addEventListener('load', function() {
                let vibrant = new Vibrant(image)
                let swatches = vibrant.swatches()
                for (let swatch in swatches) {
                    if (swatches.hasOwnProperty(swatch) && swatches[swatch]) {
                        colors.push(swatches[swatch].getHex())
                        const color = document.createElement('div')
                        color.classList.add('watch-design-info-main-color')
                        color.style.backgroundColor = swatches[swatch].getHex()
                        info_main_colors.append(color)
                        // console.log(colors)
                    }
                }
            })
            return String(colors)
        }

        const divisor = gcd(width, height);
        const ratioWidth = width / divisor;
        const ratioHeight = height / divisor;

        const aspect_ratio = String(ratioWidth + ':' + ratioHeight)
        const size = String(width + 'x' + height)

        info_aspect_ratio.textContent = aspect_ratio
        info_size.textContent = size
        info_file_type.textContent = type(cover.src)
        info_weight.textContent = cover.size
        weight(cover)

        info_main_colors.textContent = colors(cover)
    }
}

function placeDesign(design) {
    const cover = new Image()
    cover.src = design.cover

    const tags = design.tags

    const design_cover = document.getElementById('watch-design-cover')
    const design_light = document.getElementById('watch-design-light')

    const design_name = document.getElementById('watch-design-header')
    const design_bio = document.getElementById('watch-design-bio-text')

    const design_author_icon = document.getElementById('watch-design-author-icon')
    const design_author_name = document.getElementById('watch-design-author-name')
    const design_author_verification = document.getElementById('watch-design-user-verification-status')

    const design_tags = document.getElementById('watch-design-tags')
    const design_views = document.getElementById('watch-design-views')
    const design_date = document.getElementById('watch-design-date')

    // const design_rate_profies = document.getElementById('profie-TOTAL')
    // const design_rate_community = document.getElementById('community-TOTAL')

    if (design) {
        design_name.textContent = design.name
        if (design.bio) {
            design_bio.textContent = String(design.bio)
        } else {
            design_bio.textContent = 'Описания нет.'
        }

        design_author_icon.src = design.author.image
        design_author_name.textContent = design.author.username

        if (design.author.verify === true) {
            design_author_verification.innerHTML = `<div class="user-check-mark-mini icon"></div>`
        }

        design_cover.src = design.cover

        design_cover.onload = () => {
            const loader = document.getElementById('watch-design-cover-loading')
            design_light.src = design_cover.src
            loader.remove()
            getInfoDesign(cover.src)
        }

        tags.forEach(tag => {
            let tagElement = document.createElement('span')
            tagElement.classList.add('watch-design-tag')
            tagElement.textContent = tag
            design_tags.append(tagElement)
        })

        design_views.textContent = VIEWS_FORMAT(design.views) + ' просмотров'
        design_date.textContent = TIME_FORMAT(design.date) + '・'

    }
}

function loadDesign(id, name, cover, author, rate, date, tags, views, bio) {
    let design_watch = new Design(id, name, cover, author, rate, date, tags, views, bio)

    return design_watch
}

function watchDesign() {
    fetch('../json/designs.json')
        .then(response => {
            return response.json()
        })
        .then(data => {
            data.forEach(design => {
                if (Number(design.id) === Number(design_id)) {
                    const current_design = loadDesign(
                        design.id,
                        design.name,
                        design.cover,
                        design.author,
                        design.rate,
                        design.date,
                        design.tags,
                        design.views,
                        design.bio)
                    placeDesign(current_design)
                }
            })
        })
        .catch(error => {
            console.error(error)
        })
}

watchDesign()

// RATER

function createRate(id, design, author, rate) {
    const rateDesign = new Rate(id, design, author, rate)

    return rateDesign
}

let thisRate = createRate(
    1,
    14,
    'username',
    {
        T: null,
        V: null,
        D: null,
        C: null,
        OC: null,
        TI: null,
        TOTAL: null
    }
)

function rateDesign(T, V, D, C, OC, TI) {
    thisRate.rate.T = T
    thisRate.rate.V = V
    thisRate.rate.D = D
    thisRate.rate.C = C
    thisRate.rate.OC = OC
    thisRate.rate.TI = TI

    thisRate.rate.TOTAL = 0
    thisRate.rate.TOTAL = thisRate.totalCounter(thisRate.rate)
}

const total_rate = document.getElementById('watch-rater-total-rate')
const crits_rate = document.querySelectorAll('.watch-rate-crit')

rateDesign(1, 1, 1, 1, 1, 1)
total_rate.textContent = thisRate.rate.TOTAL

let T = null
let V = null
let D = null
let C = null

let OC = null
let TI = null

const rater = document.getElementById('watch-rater')

const range_inputs = document.querySelectorAll('.watch-rater-range')
const rate_marks = document.querySelectorAll('.watch-rater-crit-mark')

let isRTL = document.documentElement.dir === 'rtl'

function handleInputChange(e) {
    let target = e.target
    if (e.target.type !== 'range') {
        target = document.getElementById('range')
    }
    const min = target.min
    const max = target.max
    const val = target.value
    let percentage = (val - min) * 100 / (max - min)
    if (isRTL) {
        percentage = (max - val)
    }

    target.style.backgroundSize = percentage + '% 100%'
}

range_inputs.forEach(input => {
    input.addEventListener('input', function () {
        handleInputChange
        rate_marks.forEach(rate => {
            let rate_id = (rate.id).slice(11)
            let input_id = (input.id).slice(17)
            if (rate_id == input_id) {
                rate.textContent = input.value
            }

            switch (rate_id) {
                case 'T':
                    T = Number(rate.textContent)
                    crits_rate.forEach(crit => {
                        let crit_id = (crit.id).slice(6)
                        if (crit_id == 'T') {
                            crit.textContent = String(T)
                        }
                    })
                    break

                case 'V':
                    V = Number(rate.textContent)
                    crits_rate.forEach(crit => {
                        let crit_id = (crit.id).slice(6)
                        if (crit_id == 'V') {
                            crit.textContent = String(V)
                        }
                    })
                    break

                case 'D':
                    D = Number(rate.textContent)
                    crits_rate.forEach(crit => {
                        let crit_id = (crit.id).slice(6)
                        if (crit_id == 'D') {
                            crit.textContent = String(D)
                        }
                    })
                    break

                case 'C':
                    C = Number(rate.textContent)
                    crits_rate.forEach(crit => {
                        let crit_id = (crit.id).slice(6)
                        if (crit_id == 'C') {
                            crit.textContent = String(C)
                        }
                    })
                    break

                case 'OC':
                    OC = Number(rate.textContent)
                    crits_rate.forEach(crit => {
                        let crit_id = (crit.id).slice(6)
                        if (crit_id == 'OC') {
                            crit.textContent = String(OC)
                        }
                    })
                    break

                case 'TI':
                    TI = Number(rate.textContent)
                    crits_rate.forEach(crit => {
                        let crit_id = (crit.id).slice(6)
                        if (crit_id == 'TI') {
                            crit.textContent = String(TI)
                        }
                    })
                    break
            }

            rateDesign(T, V, D, C, OC, TI)
            total_rate.textContent = thisRate.rate.TOTAL
        })
    })
})

range_inputs.forEach(input => {
    input.addEventListener('input', handleInputChange)
})

// REVIEWER

const reviewer_name_input = document.getElementById('reviewer-name-input')
const reviewer_text_input = document.getElementById('reviewer-text-input')

const reviewer_name_counter = document.getElementById('watch-reviewer-name-symbols')
const reviewer_text_counter = document.getElementById('watch-reviewer-text-symbols')

const reviewer_format_buttons = document.querySelectorAll('.watch-reviewer-format-button')

const max_s_name = 60
const max_s_text = 2000

reviewer_name_input.setAttribute('maxlength', String(max_s_name))
reviewer_name_input.value = localStorage.getItem('reviewer_name')
reviewer_text_input.setAttribute('maxlength', String(max_s_text))
reviewer_text_input.value = localStorage.getItem('reviewer_text')

reviewer_name_counter.textContent = reviewer_name_input.value.length + '/' + max_s_name
reviewer_text_counter.textContent = reviewer_text_input.value.length + '/' + max_s_text

reviewer_name_input.addEventListener('input', function (){
    let symbol_count = reviewer_name_input.value.length
    let name = reviewer_name_input.value
    reviewer_name_counter.textContent = symbol_count + '/' + max_s_name

    if (localStorage.getItem('reviewer_name') || localStorage.getItem('reviewer_name') === '') {
        localStorage.removeItem('reviewer_name')
    }

    localStorage.setItem('reviewer_name', name)
})

reviewer_text_input.addEventListener('input', function (){
    let symbol_count = reviewer_text_input.value.length
    let text = reviewer_text_input.value
    reviewer_text_counter.textContent = symbol_count + '/' + max_s_text

    if (localStorage.getItem('reviewer_text') || localStorage.getItem('reviewer_text') === '') {
        localStorage.removeItem('reviewer_text')
    }

    localStorage.setItem('reviewer_text', text)
})

reviewer_format_buttons.forEach(button => {
    button.addEventListener('click', function (){
        const button_type = button.id

        const start = reviewer_text_input.selectionStart;
        const end = reviewer_text_input.selectionEnd;
        let selected_text = reviewer_text_input.value.substring(start, end);

        if (selected_text.length > 1) {
            if (button_type === 'format-B-button') {
                const special_symbol = '**'
                reviewer_text_input.setRangeText(special_symbol + selected_text + special_symbol, start, end, 'end')
            }

            if (button_type === 'format-I-button') {
                const special_symbol = '*'
                reviewer_text_input.setRangeText(special_symbol + selected_text + special_symbol, start, end, 'end')
            }

            if (button_type === 'format-U-button') {
                const special_symbol = '_'
                reviewer_text_input.setRangeText(special_symbol + selected_text + special_symbol, start, end, 'end')
            }
        }
    })
})